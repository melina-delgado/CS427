/* puzzle.cpp 
 *
 * Melina Delgado
 * cs427
 */

#include "puzzle.h"
#include "puzzle_move.h"
#include <iostream>
#include <sstream>
#include <string>

namespace cs427_527
{
  Puzzle::Puzzle() {}

  Puzzle::~Puzzle() {}

  PuzzleMove* readMove(std::istringstream) {}

  int Puzzle::totalMoves() const 
  {
    return movecount;
  }
  bool Puzzle::isSolved() const {}

  std::string Puzzle::toString() const {}

  bool Puzzle::isLegalMove(const PuzzleMove* move) const{}

  void Puzzle::makeMove(PuzzleMove *move){}
  
  ostream& operator<<(ostream& os, const Puzzle& out)
  {
    return os << out.toString();
  }
}
